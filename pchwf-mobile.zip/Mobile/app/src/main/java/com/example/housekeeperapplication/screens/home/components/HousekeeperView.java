package com.example.housekeeperapplication.screens.home.components;

public class HousekeeperView {
}
