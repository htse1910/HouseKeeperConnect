package com.example.housekeeperapplication.landing;

public class AboutScreen {
}
