package com.example.housekeeperapplication.store;

public class StoreManager {
}
