package com.example.housekeeperapplication.components;

public class JobListComponent {
}
