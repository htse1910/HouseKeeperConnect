package com.example.housekeeperapplication;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class HKWalletActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_housekeeper_wallet);

    }
}
