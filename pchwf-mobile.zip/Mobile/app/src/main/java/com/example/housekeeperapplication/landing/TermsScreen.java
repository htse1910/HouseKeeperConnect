package com.example.housekeeperapplication.landing;

public class TermsScreen {
}
