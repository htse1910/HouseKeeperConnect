package com.example.housekeeperapplication.admin;

public class UserManagementScreen {
}
