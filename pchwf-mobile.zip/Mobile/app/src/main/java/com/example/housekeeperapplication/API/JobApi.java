package com.example.housekeeperapplication.API;

public class JobApi {
}
