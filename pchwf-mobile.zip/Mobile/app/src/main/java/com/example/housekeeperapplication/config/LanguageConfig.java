package com.example.housekeeperapplication.config;

public class LanguageConfig {
}
