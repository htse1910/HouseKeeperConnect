package com.example.housekeeperapplication.constants;

public class JobStatusConstants {
}
