package com.example.housekeeperapplication.jobs;

public class JobDetailScreen {
}
