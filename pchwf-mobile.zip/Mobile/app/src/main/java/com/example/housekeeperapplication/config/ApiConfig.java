package com.example.housekeeperapplication.config;

public class ApiConfig {
}
