package com.example.housekeeperapplication.hooks;

public class ApiFetchHook {
}
