package com.example.housekeeperapplication.components;

public class InputComponent {
}
