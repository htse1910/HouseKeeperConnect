package com.example.housekeeperapplication.navigation;

public class GuestNavigator {
}
