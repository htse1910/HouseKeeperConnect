﻿namespace BusinessObject.DTO
{
    public class TransactionUpdateDTO
    {
        public int Status { get; set; }
    }
}